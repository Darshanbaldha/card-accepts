<!-- php start -->
<?php
// call the database.
include('partials/_connection.php');// fetch the line number of the row clickd by the admin.
$delete = $_REQUEST['sno'];
// perform the delete query for that perticuler line.
$sql = "DELETE FROM `upload_product` WHERE sno LIKE '%$delete%'";
// if query performed the so message.
if (mysqli_query($conn, $sql)) {

    echo "Record deleted successfully. Plese wait....";
    // set session.
    session_start();
    $_SESSION['product_data_delete'] = true;
    header("Location:product_delete.php");
}
// otherwise this message.
else {
    $_SESSION['product_data_delete'] = false;
    echo "Error deleting record: " . mysqli_error($con);
}
?>
<!-- php end -->