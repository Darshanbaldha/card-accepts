<!-- Sign up with gmail start -->
<?php
// give all error not show notice error.(in our case not show the session error because we use 2 times session_start() in gmail verify and simple verify.)
error_reporting(E_ALL ^ E_NOTICE);
//Include files
include('partials/_config.php');
include('partials/_connection.php');
include('partials/_bsicon.php');

$showAlertgmail = false;
// $login_button = '';

if(isset($_GET["code"]))
{
 $token = $google_client->fetchAccessTokenWithAuthCode($_GET["code"]);

 if(!isset($token['error']))
 {
  session_start();
  $google_client->setAccessToken($token['access_token']);
  $_SESSION['access_token'] = $token['access_token'];

  $google_service = new Google_Service_Oauth2($google_client);

  $data = $google_service->userinfo->get();

  if(!empty($data['given_name']))
  {
   $_SESSION['user_first_name'] = $data['given_name'];
  }

  if(!empty($data['family_name']))
  {
   $_SESSION['user_last_name'] = $data['family_name'];
  }

  if(!empty($data['email']))
  {
   $_SESSION['user_email_address'] = $data['email'];
  }

  if(!empty($data['gender']))
  {
   $_SESSION['user_gender'] = $data['gender'];
  }

  if(!empty($data['picture']))
  {
   $_SESSION['user_image'] = $data['picture'];
  }

  $name = $_SESSION['user_first_name'].$_SESSION['user_last_name'];
  $email = $_SESSION['user_email_address'];

    // sql query to select every row of the admin table of database.For name is available in database or not.
    $availablesql = "SELECT * FROM `gmail_signup` WHERE `email` = '$email'";
    // fatch the query or creating connection of sql query which is stored on he variable.
    $result1 = mysqli_query($conn,$availablesql);
    // count the numbers of the row available on the table.
    $num = mysqli_num_rows($result1);
    // if there is num available so run below condition.
    if ($num > 0) {
    $showAlertgmail = true;
    // for show signinwithgoogle button.
    unset($_SESSION['access_token']);
    // reset OAuth access token. when click on button then redirect to show all gmail id's.
    $google_client->revokeToken();
    }
    else {
        $sql = "INSERT INTO `gmail_signup`(`name`,`email`) VALUES('$name','$email')";
        // fatch the query or creating connection of sql query which is stored on the variable.
        $result = mysqli_query($conn,$sql);
        // condition for query run for the database or not.
        if ($result) {
            header("location:index.php");
            $_SESSION['loggedin'] = true;
            // $_SESSION['name'] = $name;
        }
    }
 } 
 else {
  $error = true;
  $showAlert = false;
 }
}


// if(!isset($_SESSION['access_token']))
// {

//  $login_button = '<a href="'.$google_client->createAuthUrl().'">Login With Google</a>';
// }
?>
   <?php
  //  if($login_button == '')
  //  {
  //   echo '<div class="panel-heading">Welcome User</div><div class="panel-body">';
  //   echo '<img src="'.$_SESSION["user_image"].'" class="img-responsive img-circle img-thumbnail" />';
  //   echo '<h3><b>Name :</b> '.$_SESSION['user_first_name'].' '.$_SESSION['user_last_name'].'</h3>';
  //   echo '<h3><b>Email :</b> '.$_SESSION['user_email_address'].'</h3>';
    // echo '<h3><a href="logout.php">Logout</h3></div>';
  //  }
  //  else
  //  {
  //   echo '<div align="center">'.$login_button . '</div>';
  //  }
   ?>
<!-- Sign up with gmail end -->
<!-- PHP script to insert data into databse. -->
<?php
// call the database.
// include('partials/_connection.php');  
// include('partials/_bsicon.php');      

  $showAlert = false;
  $error = false;
  $email_status = false;

  // Phpmailer
  //Import PHPMailer classes into the global namespace
  //These must be at the top of your script, not inside a function
  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\SMTP;
  use PHPMailer\PHPMailer\Exception;

  //Load Composer's autoloader
  require 'vendor/autoload.php';

  function sendmail_verify($name,$email,$token){
    //Create an instance; passing `true` enables exceptions
    $mail = new PHPMailer(true);

    //Server settings
    // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                   //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                       //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'darsb2002@gmail.com';                 //SMTP username
    $mail->Password   = 'rywnoewypbovvbsz';                           //SMTP password
    // $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    // $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('darsb2002@gmail.com', $name);
    $mail->addAddress($email);                                  //Add a recipient
    // $mail->addAddress('ellen@example.com');                  //Name is optional
    // $mail->addReplyTo('info@example.com', 'Information');
    // $mail->addCC('cc@example.com');
    // $mail->addBCC('bcc@example.com');

    //Attachments
    // $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
    // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);                                   //Set email format to HTML
    $mail->Subject = 'Email verification from card-accept';
    $email_body = "<h4>Hi <b>$name</b>,</h4>
                  <h4>Welcome to card-accept!</h4>
                  <h4>Please verify your email so we Know it's really you!</h4>
                  <br></br>
                  <a href ='http://localhost/payment%20gateway/1st%20try/email_verifying.php?token=$token'>Verify your email</a>
                  <h4>Team Card-accept</h4>";
    $mail->Body    = $email_body;
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Message has been sent';
  }

  // if click on log in button.
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // fatched data enter by the user.
    $name = $_POST['name'];
    $number = $_POST['number'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    // sql query to select every row of the admin table of database.For name is available in database or not.
    $availablesql = "SELECT * FROM `signup` WHERE name = '$name'";
    // fatch the query or creating connection of sql query which is stored on he variable.
    $result1 = mysqli_query($conn,$availablesql);
    // count the numbers of the row available on the table.
    $num = mysqli_num_rows($result1);
    // if there is num available so run below condition.
    if ($num > 0) {
      // echo "<h1>Username already taken.</h1>";
      // if username already taken then show error variable is run.
      $showAlert = true;
      $error = false;
    }
    // if there num is not available then use this code.
    else {
      // generate hash code of the password.
      $hash_password = password_hash($password, PASSWORD_DEFAULT);
      // Generate random token for each user.
      $token = md5(rand());
      $status = "inactive";
      // sql query to select every row of the admin table of database.
      $sql = "INSERT INTO `signup`(`name`,`number`,`email`,`password`,`token`,`status`) VALUES('$name','$number','$email','$hash_password','$token','$status')";
      // fatch the query or creating connection of sql query which is stored on the variable.
      $result = mysqli_query($conn,$sql);
      // session_start();
      if (session_status() === PHP_SESSION_NONE) {
        session_start();
      }
      // set the session.
      $_SESSION['loggedin'] = true;
      $_SESSION['name'] = $name;
      // $_SESSION['password'] = $password;
      // condition for query run for the database or not.
      if ($result) {
        sendmail_verify("$name","$email","$token");
        // $_SESSION['email_status'] = "Registration successfull.Plese verify your email."
        header("location:signup_gmail_check.php");
      } else {
        // echo "Error.";
        $error = true;
        $showAlert = false;
        $email_status = false;
        // $email_status_error = true;
        // $_SESSION['email_status'] = "failed."
      }      
    }
  }
?>
<!-- php end -->
<!-- html and bootstrap start -->
<!DOCTYPE html>
<html lang="en">
  <!-- head start -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="css/style.css">
    <!-- bootstrap css 5.3.0-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>
<!-- head end -->
<body>
  <!-- php start -->
  <?php
    // alert show
    if ($showAlert) {
      echo '<div class="alert alert-danger d-flex align-items-center" role="alert" style="height:30%">
              <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
              <div>
                <h3><strong>Unsuccess!</strong>Username already taken.</h3>
              </div>
              
            </div>';
    }
    if ($showAlertgmail) {
      echo '<div class="alert alert-danger d-flex align-items-center" role="alert" style="height:30%">
              <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
              <div>
                <h3><strong>Unsuccess!</strong>You hvae already account.Plese log in to use web site.</h3>
              </div>
              
            </div>';
    }
    // error show
    if ($error) {
      echo '<div class="alert alert-danger d-flex align-items-center" role="alert">
              <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
              <div>
                <h3><strong>Unsuccess!</strong>There is an error.Plese try again!</h3>
              </div>
            </div>';
    }
  ?>
  <!-- php end -->
    <!-- Sign up Form start -->
      <div class="d-flex flex-column align-items-center mt-5">
        <form class="px-4 py-3" method="post">
          <!-- enter name start-->
          <div class="mb-3">
            <label for="exampleDropdownFormname" class="form-label">Name</label>
            <input type="text" class="form-control" id="exampleDropdownFormname" placeholder="Enter your name" name="name" maxlength="30" required>
          </div>
          <!-- enter name end-->
          <!-- enter number start-->
          <div class="mb-3">
            <label for="exampleDropdownFormnumber" class="form-label">Phone No.</label>
            <input type="tel" class="form-control" id="exampleDropdownFormnumber" placeholder="Enter your number" name="number" maxlength="10" required>
          </div>
          <!-- enter number end-->
          <!-- enter email start-->
          <div class="mb-3">
            <label for="exampleDropdownFormEmail1" class="form-label">Email address</label>
            <input type="email" class="form-control" id="exampleDropdownFormEmail1" placeholder="email@example.com" name="email" maxlength="30" required>
          </div>
          <!-- enter email end-->
          <!-- enter password start-->
          <div class="mb-3">
            <label for="exampleDropdownFormPassword1" class="form-label">Password</label>
            <input type="password" class="form-control" id="exampleDropdownFormPassword1" placeholder="Password" name="password" maxlength="255" required>
          </div>
          <!-- enter password end-->
          <button type="submit" name="submit" class="btn btn-primary">Sign Up</button>
        </form>
        <div class="">
            <a class="dropdown-item" href="./login.php">Already User? Log In</a>
        </div>
        <!-- sign up with google start -->
        <div class="">
          <h2 class="d-flex justify-content-center">OR</h2>
          <?php
            if(!isset($_SESSION['access_token']))
            {
              // $login_button = '<a href="'.$google_client->createAuthUrl().'">Login With Google</a>';
              $login_button = '<a href="'.$google_client->createAuthUrl().'"><button type="button" class="btn btn-primary"><i class="fa-brands fa-google" style="color: #ffffff;"></i> Sign in with Google</button></a>';
              echo '<div align="center">'.$login_button . '</div>';
            }
          ?>
        </div>
      </div>
        <!-- sign up with google end -->
    <!-- Sign up Form end -->
    <!-- Bootstrap js 5.3.0-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

    <!-- fontawsome -->
    <!-- <script src="https://kit.fontawesome.com/b1d2dc365e.js" crossorigin="anonymous"></script> -->
</body>
</html>
<!-- html and bootstrap end -->