<?php
  include('partials/_connection.php');
  include('partials/_bsicon.php');
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>plese verify your gmail</title>
    <!-- bootstrap css 5.3.0-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>
<body>
    <?php
    $email_status = true;
if ($email_status == true) {
      echo '<div class="alert alert-success d-flex align-items-center" role="alert">
      <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
      <div>
        <h3><strong>Registration Successfull!</strong>Plese Verify your email.</h3>
      </div>
    </div>';
    }
    if (isset($_SESSION['status'])) {
      ?>
        <div class="alert alert-success d-flex align-items-center" role="alert">
                <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
                <div>
                    <h3><?= $_SESSION['status']; ?></h3>
                </div>
        </div>
        <?php
        unset($_SESSION['status']);
      }
    ?>
    <!-- Log in Form start -->
    <div class="d-flex flex-column align-items-center mt-5">
    <div class="px-4 py-3">
      <!-- <a class="dropdown-item" href="./signup.php">Don't have account?Plese, Sign up</a>
      <a class="dropdown-item" href="#">Forgot password?</a> -->
      <p class="dropdown-item">Didn't receive email.Plese enter your email here!</p>
    </div>
        <form class="px-4 py-3" method="post">
          <!-- enter name start-->
        <!-- <div class="mb-3">
            <label for="exampleDropdownFormname" class="form-label" required>Name(must be in lowercase)</label>
            <input type="text" class="form-control" id="exampleDropdownFormname" placeholder="Enter your name" name="name" maxlength="30" value="" required>
          </div> -->
          <!-- enter name end-->
          <!-- enter email start-->
          <div class="mb-3">
            <label for="exampleDropdownFormEmail1" class="form-label">Email address</label>
            <input type="email" class="form-control" id="exampleDropdownFormEmail1" placeholder="email@example.com" name="email" maxlength="255">
          </div>
          <!-- enter email end-->
          <!-- enter password start-->
          <!-- <div class="mb-3">
            <label for="exampleDropdownFormPassword1" class="form-label">Password</label>
            <input type="password" class="form-control" id="exampleDropdownFormPassword1" placeholder="Password" name="password" maxlength="255" value="">
          </div> -->
          <!-- enter password end-->
          <button type="submit" class="btn btn-primary">Resend</button>
        </form>
    </div>
    <!-- Log in Form end -->
    <!-- Bootstrap js 5.3.0-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>
<?php
  // Phpmailer
  //Import PHPMailer classes into the global namespace
  //These must be at the top of your script, not inside a function
  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\SMTP;
  use PHPMailer\PHPMailer\Exception;

  //Load Composer's autoloader
  require 'vendor/autoload.php';

function resend_email_verify($name,$email,$token){
   //Create an instance; passing `true` enables exceptions
   $mail = new PHPMailer(true);

   //Server settings
   // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                   //Enable verbose debug output
   $mail->isSMTP();                                            //Send using SMTP
   $mail->Host       = 'smtp.gmail.com';                       //Set the SMTP server to send through
   $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
   $mail->Username   = 'darsb2002@gmail.com';                 //SMTP username
   $mail->Password   = 'rywnoewypbovvbsz';                           //SMTP password
   // $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
   // $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
   $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

   //Recipients
   $mail->setFrom('darsb2002@gmail.com', $name);
   $mail->addAddress($email);                                  //Add a recipient
   // $mail->addAddress('ellen@example.com');                  //Name is optional
   // $mail->addReplyTo('info@example.com', 'Information');
   // $mail->addCC('cc@example.com');
   // $mail->addBCC('bcc@example.com');

   //Attachments
   // $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
   // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

   //Content
   $mail->isHTML(true);                                   //Set email format to HTML
   $mail->Subject = 'Email Re-verification from card-accept';
   $email_body = "<h4>Hi <b>$name</b>,</h4>
                 <h4>Welcome to card-accept!</h4>
                 <h4>Please Re-verify your email so we Know it's really you!</h4>
                 <br></br>
                 <a href ='http://localhost/payment%20gateway/1st%20try/email_verifying.php?token=$token'>Verify your email</a>
                 <h4>Team Card-accept</h4>";
   $mail->Body    = $email_body;
   $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

   $mail->send();
   echo 'Message has been sent';
}

if (isset($_POST['submit'])) {
  $email_status = false;
 if (!empty(trim($_POST['email']))) {
  $email = $_POST['email'];

  $sql = "SELECT * FROM `signup` WHERE email = '$email' LIMIT 1";
  $result = mysqli_query($conn,$sql);

  if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_array($result);
    if ($row['status'] == "inactive") {
      $name = $row['name'];
      $email = $row['email'];
      $token = $row['token'];
      resend_email_verify($name,$email,$token);
      $_SESSION['status'] = "Link send to your email!";
      header('Location:signup_gmail_check.php');
      exit(0);
    } else {
      $_SESSION['status'] = "You are already sign in.Plese login";
      header('Location:login.php');
      exit(0);
    }
  } else {
    $_SESSION['status'] = "You are not sign in!Plsese sign in again.";
    header('Location:signin.php');
    exit(0);
  }
 } else {
  $_SESSION['status'] = "Plses enter the email field!";
 }
}
?>