<?php
session_start();
// call the database.
include('partials/_connection.php');  
include('partials/_bsicon.php');

if(isset($_GET['token']))
{
    // get token
    $token = $_GET['token'];
    // select rows from the table
    $sql = "SELECT * FROM `signup` WHERE token='$token'";
    // run the query
    $result = mysqli_query($conn,$sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_array($result);
        if ($row[6] == "inactive") {
            $update_sql = "UPDATE `signup` SET `status`='active' LIMIT 1";
            $update_result = mysqli_query($conn,$update_sql);
            if ($update_result) {
                $email_status = true;
                // echo "1";
                header("location:index.php");
                exit(0);
            } else {
                $_SESSION['email_status'] = "Varification failed.";
                header("location:email_verifying.php");
                // echo "2";
                exit(0);
            }
            
        } else {
            $_SESSION['email_status'] = "Email already verified.Plese Login.";
            header("location:email_verifying.php");
            // echo "3";
            exit(0);
        }
        
    } else {
        $_SESSION['email_status'] = "Plese Sign in again.";
        header("location:email_verifying.php");
        // echo "4";
        exit(0);
    }
} else {
    $_SESSION['email_status'] = "Plese Sign in again.";
    header("location:email_verifying.php");
    // echo "5";
    exit(0);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>plese verify your gmail</title>
    <!-- bootstrap css 5.3.0-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>
<body>
    <?php
    if ($email_status) {
      echo '<div class="alert alert-success d-flex align-items-center" role="alert">
      <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
      <div>
        <h3><strong>Registration Successfull!</strong>Plese Verify your email.</h3>
      </div>
    </div>';
    }
    if (isset($_SESSION['email_status'])) {
    ?>
        <div class="alert alert-success d-flex align-items-center" role="alert">
                <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
                <div>
                    <h3><strong>Registration Successfull!</strong><?= $_SESSION['email_status']; ?></h3>
                </div>
        </div>
        <?php
        unset($_SESSION['email_status']);
    }
    ?>

    <!-- Bootstrap js 5.3.0-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>