<?php
// start the session.
session_start();
// destroy the variable of the session.
session_unset();
// destroy the cookie.
// setcookie('name_cookie',$name,time()-1);
// setcookie('password_cookie',$password,time()-1);
// destroy the session.
session_destroy();
// redirect to the location.
header("Location:signup.php");
exit;
?>
<!-- gmail logout -->
<?php
include('config.php');

//Reset OAuth access token
$google_client->revokeToken();

//Destroy entire session data.
session_unset();
session_destroy();

//redirect page to index.php
header('location:signup.php');
?>