<!-- php start -->
<?php
  // call the database.
include('partials/_connection.php');  
  include('partials/_bsicon.php');
  // session start.
  session_start();
  // condition for only the admin comes to the page.
  if (!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true || !isset($_SESSION['admin']) || isset($_SESSION['admin'])!=true) {
    header("Location:login.php");
    exit;
  }
  else{
    $loggedin = false;
    $admin = true;
  }
?>
<!-- php end -->
<!-- html and bootstrap start -->
<!DOCTYPE html>
<html lang="en">
<!-- head start -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Data</title>
    <link rel="stylesheet" href="css/style.css">
    
    <!-- bootstrap css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>
<!-- head end -->
<body>
<?php include_once('partials/_nav.php');?>
    
    <div class="">
    <p class="p">Hello <?php if (isset($_SESSION['name'])) {
                echo $_SESSION['name'];
              } else {
                echo $_SESSION['user_first_name'].' '.$_SESSION['user_last_name'];
              }
              ?></p>
    </div>
  <!-- Table start -->
    <?php
      if (isset($_SESSION['user_data_delete'])) {
        echo '<div class="alert alert-success d-flex align-items-center" role="alert">
                <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
                <div>
                  <h3>User Data deleted successffull.</h3>
                </div>
              </div>';
      }
        echo "<div class='container'>";
        echo "<table class='table table-hover table-bordered border-primary'id ='datatable'>";
        echo "<thead><tr class='table-primary'><th>S.no</th><th>User Name</th><th>Number</th><th>Email Id</th><th>Sign Up Date&Time</th><th colspan='2'>Custmize</th></tr></thead>";
        $sql = "SELECT * FROM `signup`";
        $result = mysqli_query($conn,$sql);
        if($sql){
          while ($row = mysqli_fetch_row($result)){
                echo "<tbody><tr><td>$row[0]</td>";
                echo "<td>$row[1]</td>";
                echo "<td>$row[2]</td>";
                echo "<td>$row[3]</td>";
                echo "<td>$row[5]</td>";
                echo "<td><a href='user_data_delete.php?sno=$row[0]' onclick='return checkdelete()' class='btn btn-outline-danger'>Delete</a></td></tr></tbody>";
            }
        }
        else {
            echo "Error in select query";
        }
        echo "</table>";
        echo "</div>";
    ?>
  <!-- Table end -->
  <!-- Bootstrap js -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>
<!-- html and bootstrap end -->