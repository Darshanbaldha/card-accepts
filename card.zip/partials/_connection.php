<!-- DataBase connection code -->
<?php
    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "firsttry";

    $conn = mysqli_connect($server,$username,$password,$database);

    if (!$conn) {
        die("ERROR : Plese Connect to Admin.");
    }
?>
<!-- DataBase connection code -->
<?php
    //  $server = "localhost";
    //  $username = "id21126518_root";
    //  $password = "j%;[S2!~>;f-&X?]|{66D3D";
    //  $database = "id21126518_firsttry";

    //  $conn = mysqli_connect($server,$username,$password,$database);

    //  if (!$conn) {
    //      die("ERROR : Plese Connect to Admin.");
    //  }
?>