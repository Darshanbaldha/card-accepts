<!-- Navbar start -->
<nav class="navbar navbar-expand-xxl navbar-dark bg-primary">
    <!-- <nav class="navbar navbar-expand-lg navbar-dark bg-primary"> -->
        <div class="container-fluid">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active fs-3" aria-current="page" href="./index.php">Home</a>
              </li>
              <?php
              if ($loggedin) {
                echo '<li class="nav-item">
                  <a class="nav-link fs-3" href="./signup.php">Sign Up</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link fs-3" href="./login.php">Log In</a>
                </li>';
              }
              ?>
              <?php
              if (!$loggedin) {
                echo '<li class="nav-item">
                <a class="nav-link fs-3" href="./logout.php">Log Out</a>
              </li>';
              }
              if ($admin && $_SESSION['admin'] == true) {
                echo '<li class="nav-item">
                <a class="nav-link fs-3" href="./user_data.php">User data</a>
              </li>
              <li class="nav-item">
                <a class="nav-link fs-3" href="./admin_data.php">Admin data</a>
              </li>
              <li class="nav-item">
                <a class="nav-link fs-3" href="./gmail_user_data.php">Gmail User data</a>
              </li>
              <li class="nav-item">
                <a class="nav-link fs-3" href="./slider_upload.php">Upload Slider</a>
              </li>
              <li class="nav-item">
                <a class="nav-link fs-3" href="./upload_product.php">Upload Product</a>
              </li>
              <li class="nav-item">
                <a class="nav-link fs-3" href="./product_delete.php">Delete Product</a>
              </li>';
              }
            ?>
            </ul>
          </div>
          
            <h3 class="text-white">Hello <?php if (isset($_SESSION['name'])) {
                echo $_SESSION['name'];
              } else {
                echo $_SESSION['user_first_name'].' '.$_SESSION['user_last_name'];
              }
              ?>
            </h3>
        </div>
    </nav>
    <!-- Navbar end -->