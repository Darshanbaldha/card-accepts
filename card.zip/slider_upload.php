<!-- php start -->
<?php
  // call the database.
  include('partials/_connection.php');  
  include('partials/_bsicon.php');
  // session start.
  session_start();
  // condition for only the admin comes to the page.
  if (!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true || !isset($_SESSION['admin']) || isset($_SESSION['admin'])!=true) {
    header("Location:login.php");
    exit;
  }
  else{
    $loggedin = false;
    $admin = true;
    $extension_error = false;
    $slider_success = false;
    // $_SESSION['extension_error'] = false;
    // if click on upload in button.
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      // fatched data enter by the user.
      $filename = time() . '_' . $_FILES["product_image"]["name"];
      $tempname = $_FILES["product_image"]["tmp_name"];
      $folder = "./images/" . $filename;
      $fileextension = pathinfo($filename, PATHINFO_EXTENSION);
      $extension = array("jpeg","jpg","png","gif");
      if (in_array($fileextension,$extension) === false) {
        // $_SESSION['extension_error'] = false;
        // unset($_SESSION['upload_success']);
        $extension_error = true;
        $upload_success = false;
          // echo "Extension is not allowed,please choose jpeg , jpg , gif or png.";
      }
      else{
        $extension_error = false;
        $upload_success = true;
          move_uploaded_file($tempname,$folder);
          // sql query to upload product of database.
          $sql = "INSERT INTO `upload_slider`(`product_image`) VALUES('$folder')";
          // fatch the query or creating connection of sql query which is stored on the variable.
          $result = mysqli_query($conn,$sql);
          // condition for query run for the database or not.
          if ($result) {
            // header("location:index.php");
            $slider_success = true;
          } else {
            // echo "Error.";
            $error = true;
            // $showAlert = false;
            $slider_success = false;
          }
      }   
    }
  }
?>
<!-- php end -->
<!-- html and bootstrap start -->
<!DOCTYPE html>
<html lang="en">
<!-- head start -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Slider Upload</title>
    <link rel="stylesheet" href="css/style.css">
    
    <!-- bootstrap css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>
<!-- head end -->
<body>
<?php include_once('partials/_nav.php');?>
    
    <div class="">
    <p class="p">Hello <?php if (isset($_SESSION['name'])) {
                echo $_SESSION['name'];
              } else {
                echo $_SESSION['user_first_name'].' '.$_SESSION['user_last_name'];
              }
              ?></p>
    </div>
<?php
    if ($slider_success == true) {
        echo '<div class="alert alert-success d-flex align-items-center" role="alert">
                <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
                <div>
                  <h3>Product Upload successfull.</h3>
                </div>
              </div>';
      }
      if ($extension_error == true) {
        echo '<div class="alert alert-danger d-flex align-items-center" role="alert" style="height:30%">
                <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                <div>
                  <h3><strong>Unsuccess!</strong>Extension is not allowed,please choose jpeg , jpg , gif or png.</h3>
                </div>
              </div>';
      }
?>
<!-- product upload form start -->
    <div class="d-flex flex-column align-items-center">
        <form class="px-4" method="post" action="" enctype="multipart/form-data">
          <!-- upload image of product start-->
          <div class="mb-3">
            <label for="formFile" class="form-label">Product's Image</label>
            <input class="form-control" type="file" id="formFile" name="product_image">
          </div>
          <!-- upload image of product end-->
          <!-- enter password end-->
          <button type="submit" name="submit" class="btn btn-primary">Upload</button>
        </form>
      </div>
<!-- product upload form end -->

  <!-- Bootstrap js -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>
<!-- html and bootstrap end -->