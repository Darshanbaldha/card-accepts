<?php
  include('partials/_connection.php');
  include('partials/_bsicon.php');
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Change</title>
    <!-- bootstrap css 5.3.0-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>
<body>
    <?php
//     $email_status = true;
// if ($email_status == true) {
//       echo '<div class="alert alert-success d-flex align-items-center" role="alert">
//       <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
//       <div>
//         <h3><strong>Registration Successfull!</strong>Plese Verify your email.</h3>
//       </div>
//     </div>';
//     }
    if (isset($_SESSION['status'])) {
      echo "HI";?>
        <div class="alert alert-success d-flex align-items-center" role="alert">
                <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
                <div>
                    <h3><?= $_SESSION['status']; ?></h3>
                </div>
        </div>
        <?php
        unset($_SESSION['status']);
      }
    ?>
    <!-- Log in Form start -->
    <div class="d-flex flex-column align-items-center mt-5">
        <form class="px-4 py-3" method="post">
            <input type="hidden" name="password_token" value="<?php if (isset($_GET['token'])) {
                echo $_GET['token'];
            } ?>">
          <div class="mb-3">
            <label for="exampleDropdownFormEmail1" class="form-label">Email address</label>
            <input type="email" class="form-control" id="exampleDropdownFormEmail1" placeholder="email@example.com" name="email" maxlength="255" value="<?php if (isset($_GET['email'])) {
                echo $_GET['email'];
            } ?>">
          </div>
          <!-- enter email end-->
          <!-- enter password start-->
          <div class="mb-3">
            <label for="exampleDropdownFormPassword1" class="form-label">Password</label>
            <input type="password" class="form-control" id="exampleDropdownFormPassword1" placeholder="Password" name="password" maxlength="255" value="">
          </div>
          <!-- enter password end-->
          <!-- enter password start-->
          <div class="mb-3">
            <label for="exampleDropdownFormPassword1" class="form-label">Conform Password</label>
            <input type="password" class="form-control" id="exampleDropdownFormPassword1" placeholder="Conform Password" name="cpassword" maxlength="255" value="">
          </div>
          <!-- enter password end-->
          <button type="submit" name="submit" class="btn btn-primary">Change Password</button>
        </form>
    </div>
    <!-- Log in Form end -->
    <!-- Bootstrap js 5.3.0-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>
<?php
if (isset($_POST['submit'])) {
  $email = $_POST['email'];
  $password = $_POST['password'];
  $cpassword = $_POST['cpassword'];
  $token = $_POST['password_token'];

  if (!empty($token)) {
    if (!empty($email) && !empty($password) && !empty($cpassword)) {
      // sql query for select token
        $check_token_sql = "SELECT token FROM signup WHERE token='$token' LIMIT 1";
        $result = mysqli_query($conn,$check_token_sql);
        if (mysqli_num_rows($result) > 0) {
          if ($password === $cpassword) {
            // generate hash code of the password.
            $hash_password = password_hash($password, PASSWORD_DEFAULT);
            $update_query = "UPDATE signup SET password='$hash_password' WHERE token='$token' LIMIT 1";
            $update_result = mysqli_query($conn,$update_query);
            if ($update_result) {
              $new_token = md5(rand());
              $update_token_query = "UPDATE signup SET token='$new_token' WHERE token='$token' LIMIT 1";
              $update_result = mysqli_query($conn,$update_token_query);
              $_SESSION['status'] = "Password Reset.";
              header("location:login.php");
              exit(0);
            } else {
              $_SESSION['status'] = "Password not reset.Plese try again!";
              header("location:password_changing.php?token=$token&email=$email");
              exit(0);
            }
            
          } else {
            $_SESSION['status'] = "Password and Conform password not match.";
            header("location:password_changing.php?token=$token&email=$email");
            exit(0);
          }
          
        } else {
          $_SESSION['status'] = "Invalid Request!";
          header("location:password_changing.php?token=$token&email=$email");
          exit(0);
        }
    } else {
        $_SESSION['status'] = "Plese insert a password!";
        header("location:password_changing.php?token=$token&email=$email");
        exit(0);
    }
    
  } else {
    $_SESSION['status'] = "Error! Plese go to Forgot password page.";
    header("location:password_changing.php");
    exit(0);
  }
  
}
?>