<!-- Sign up with gmail start -->
<?php
// give all error not show notice error.(in our case not show the session error because we use 2 times session_start() in gmail verify and simple verify.)
error_reporting(E_ALL ^ E_NOTICE);
//Include files
include('partials/_config1.php');
include('partials/_connection.php');
include('partials/_bsicon.php');
$showAlert = false;
$error = false;
$showAlertgmail = false;
// $login_button = '';
if(isset($_GET["code"]))
{
 $token = $google_client->fetchAccessTokenWithAuthCode($_GET["code"]);

 if(!isset($token['error']))
 {
  session_start();
  $google_client->setAccessToken($token['access_token']);
  $_SESSION['access_token'] = $token['access_token'];

  $google_service = new Google_Service_Oauth2($google_client);

  $data = $google_service->userinfo->get();

  if(!empty($data['given_name']))
  {
   $_SESSION['user_first_name'] = $data['given_name'];
  }

  if(!empty($data['family_name']))
  {
   $_SESSION['user_last_name'] = $data['family_name'];
  }

  if(!empty($data['email']))
  {
   $_SESSION['user_email_address'] = $data['email'];
  }

  if(!empty($data['gender']))
  {
   $_SESSION['user_gender'] = $data['gender'];
  }

  if(!empty($data['picture']))
  {
   $_SESSION['user_image'] = $data['picture'];
  }

  $name = $_SESSION['user_first_name'].$_SESSION['user_last_name'];
  $email = $_SESSION['user_email_address'];

  // sql query to select every row of the user(signup) table of database.
  $sql = "SELECT * FROM `gmail_signup`";
  // fatch the query or creating connection of sql query which is stored on he variable.
  $result = mysqli_query($conn,$sql);
  // count the numbers of the row available on the table.
  $num = mysqli_num_rows($result);

  // if there is num available so run below condition.
  if ($num == 1) {
    // loop is for fetch all row of table.
    while ($row=mysqli_fetch_assoc($result)) {
      // if condition verify the password using row fetch by the loop.
      if ($row['email'] == $email) {
        // session_start();
        // set the session.
        $_SESSION['loggedin'] = true;
        // $_SESSION['name'] = $name;
        header("Location:index.php");
      } else {
        // echo "Plese enter valid name and password.";
        $showAlertgmail = true;
        $error = false;
        // for show signinwithgoogle button.
        unset($_SESSION['access_token']);
        // reset OAuth access token. when click on button then redirect to show all gmail id's.
        $google_client->revokeToken();
      }
    }
  }
  else {
    $showAlertgmail = true;
    $error = false;
    // for show signinwithgoogle button.
    unset($_SESSION['access_token']);
    // reset OAuth access token. when click on button then redirect to show all gmail id's.
    $google_client->revokeToken();
  }
 } 
}
?>
<!-- php start -->
<?php
// call the database.
  include('partials/_connection.php');  
  include('partials/_bsicon.php');      

  $showAlert = false;
  $error = false;

  // if click on log in button.
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      // session_start();
      if (session_status() === PHP_SESSION_NONE) {
        session_start();
      }
      ob_start();
      // fatched data enter by the user.
      $name = $_POST['name'];
      $password = $_POST['password'];
      // chacked if admin log in.
      if ($name == "admin") {
        // sql query to select every row of the admin table of database.
        $sql1 = "SELECT * FROM `admin_login` WHERE name = '$name'";
        // fatch the query or creating connection of sql query which is stored on the variable. 
        $result1 = mysqli_query($conn,$sql1);

        // loop is for fetch all row of table.
        while ($row=mysqli_fetch_assoc($result1)){  
            // if condition verify the password using row fetch by the loop.
          if (password_verify($password,$row['password'])) {
            // session_home();
            $admin = true;
            // set the session.
            $_SESSION['loggedin'] = true;
            $_SESSION['admin'] = true;
            $_SESSION['name'] = $name;
            header("Location:index.php");
          }
          // if password dose't verify then show the error.
          else {
            // echo "Plese enter valid name and password.";
            $showAlert = true;
            $error = false;
          }
        }
      }
      // if admin dose't logged in then that case check the user logged in.
      else {
        // sql query to select every row of the user(signup) table of database.
          $sql = "SELECT * FROM `signup` WHERE name = '$name'";
          // fatch the query or creating connection of sql query which is stored on he variable.
          $result = mysqli_query($conn,$sql);
          // count the numbers of the row available on the table.
          $num = mysqli_num_rows($result);
          // if there is num available so run below condition.
          if ($num == 1) {
            // loop is for fetch all row of table.
            while ($row=mysqli_fetch_assoc($result)) {
              // if condition verify the password using row fetch by the loop.
              if (password_verify($password,$row['password'])) {
                // session_start();
                // set the session.
                $_SESSION['loggedin'] = true;
                $_SESSION['name'] = $name;
                header("Location:index.php");
              } else {
                // echo "Plese enter valid name and password.";
                $showAlert = true;
                $error = false;
              }
            }
          }
          // if in database no row available.
          else {
            // echo "Plese enter valid name and password.";
            $error = false;
            $showAlert = true;
          }
        }
    }
?>
<!-- php end -->
<!-- html and bootstrap start -->
<!DOCTYPE html>
<html lang="en">
<!-- head start -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In</title>
    <link rel="stylesheet" href="css/style.css">
    
    <!-- bootstrap css version 5.3.0-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>
<!-- head end -->
<body>
  <!-- php start -->
  <?php
    // alert show
    if ($showAlert) {
      echo '<div class="alert alert-danger d-flex align-items-center" role="alert">
              <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
              <div>
                <h3><strong>Unsuccess!</strong>Plese enter valid name and password.</h3>
              </div>
            </div>';
    }
    if ($showAlertgmail) {
      echo '<div class="alert alert-danger d-flex align-items-center" role="alert" style="height:30%">
              <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
              <div>
                <h3><strong>Unsuccess!</strong>You don\'t Have an account.Plese create account first.</h3>
              </div>
              
            </div>';
    }
    // error show
    if ($error) {
      echo '<div class="alert alert-danger d-flex align-items-center" role="alert">
              <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
              <div>
                <h3><strong>Unsuccess!</strong>There is an error.Plese try again!</h3>
              </div>
            </div>';
    }
  ?>
  <!-- php end -->
    <!-- Log in Form start -->
    <div class="d-flex flex-column align-items-center mt-5">
        <form class="px-4 py-3" method="post">
          <!-- enter name start-->
        <div class="mb-3">
            <label for="exampleDropdownFormname" class="form-label" required>Name(must be in lowercase)</label>
            <input type="text" class="form-control" id="exampleDropdownFormname" placeholder="Enter your name" name="name" maxlength="30" value="<?php if (isset($_COOKIE['name_cookie'])) {
              echo $_COOKIE['name_cookie'];
            } ?>" required>
          </div>
          <!-- enter name end-->
          <!-- enter email start-->
          <!-- <div class="mb-3">
            <label for="exampleDropdownFormEmail1" class="form-label">Email address</label>
            <input type="email" class="form-control" id="exampleDropdownFormEmail1" placeholder="email@example.com" name="email">
          </div> -->
          <!-- enter email end-->
          <!-- enter password start-->
          <div class="mb-3">
            <label for="exampleDropdownFormPassword1" class="form-label">Password</label>
            <input type="password" class="form-control" id="exampleDropdownFormPassword1" placeholder="Password" name="password" maxlength="255" value="<?php if (isset($_COOKIE['password_cookie'])) {
              echo $_COOKIE['password_cookie'];
            } ?>">
          </div>
          <!-- enter password end-->
          <button type="submit" class="btn btn-primary">Log in</button>
        </form>
         <!-- sign up with google start -->
         <div class="px-4 py-3">
          <h2 class="d-flex justify-content-center">OR</h2>
          <?php
            if(!isset($_SESSION['access_token']))
            {
              // $login_button = '<a href="'.$google_client->createAuthUrl().'">Login With Google</a>';
              $login_button = '<a href="'.$google_client->createAuthUrl().'"><button type="button" class="btn btn-primary"> <i class="fa-brands fa-google" style="color: #ffffff;"></i> Log in with Google</button></a>';
              echo '<div align="center">'.$login_button . '</div>';
            }
          ?>
        </div>
        <div class="px-4 py-3">
            <a class="dropdown-item" href="./signup.php">Don't have account?Plese, Sign up</a>
            <a class="dropdown-item" href="./forgot.php">Forgot password?</a>
        </div>
    </div>
    <!-- Log in Form end -->
    
    <!-- Bootstrap js 5.3.0-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

      <!-- fontawsome -->
      <!-- <script src="https://kit.fontawesome.com/b1d2dc365e.js" crossorigin="anonymous"></script> -->
</body>
</html>
<!-- html and bootstrap end -->