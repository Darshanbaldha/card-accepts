<!-- php start -->
<?php
  // fetch upload_product from database start
  // call the database.
  include('partials/_connection.php');  
  include('partials/_bsicon.php');
  
  // session start.
  session_start();
  // if without logging someone enter the web site the go to the logout page.
  if (!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true) {
    header("Location:login.php");
    exit;
  }
  // otherwise run the current page.
  else{
    $loggedin = false;
    // if admin dosen't enter on the web site then set as the user page.
    if (!isset($_SESSION['admin']) || isset($_SESSION['admin'])!=true) {
      $admin = false;
    }
    // otherwise set as the admin page.
    else {
      $admin = true;
    }
  }
?>
<!-- php end -->
<!-- html and bootstrap start -->
<!DOCTYPE html>
<html lang="en">
<!-- head start -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home <?php if (isset($_SESSION['name'])) {
                echo $_SESSION['name'];
              } else {
                echo $_SESSION['user_first_name'].' '.$_SESSION['user_last_name'];
              }
              ?></title>
    <link rel="stylesheet" href="css/style.css">
    <!-- bootstrap css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>
<body>
    <?php include_once('partials/_nav.php');?>
    
    <!-- carousel start -->
    <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
        <!-- <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
          <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="3" aria-label="Slide 4"></button>
          <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="4" aria-label="Slide 5"></button>
          <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="5" aria-label="Slide 6"></button>
        </div> -->
        <div class="carousel-inner">
          <div class="carousel-item active" data-bs-interval="2000">
            <img src="img\img5.jpeg" class="img-fluid imgwidth rounded" alt="image1">
            <div class="carousel-caption d-none d-md-block">
              <!-- <h5>First slide label</h5> -->
              <!-- <p>Some representative placeholder content for the first slide.</p> -->
            </div>
          </div>
          <div class="carousel-item" data-bs-interval="2000">
            <img src="img\img6.jpeg" class="img-fluid imgwidth rounded" alt="image2">
            <div class="carousel-caption d-none d-md-block">
              <!-- <h5>Second slide label</h5> -->
              <!-- <p>Some representative placeholder content for the second slide.</p> -->
            </div>
          </div>
          <div class="carousel-item" data-bs-interval="2000">
            <img src="img\img7.jpeg" class="img-fluid imgwidth rounded" alt="image3">
            <div class="carousel-caption d-none d-md-block">
              <!-- <h5>Third slide label</h5> -->
              <!-- <p>Some representative placeholder content for the third slide.</p> -->
            </div>
          </div>
          <div class="carousel-item" data-bs-interval="2000">
            <img src="img\img8.jpeg" class="img-fluid imgwidth rounded" alt="image4">
            <div class="carousel-caption d-none d-md-block">
              <!-- <h5>Fourth slide label</h5> -->
              <!-- <p>Some representative placeholder content for the third slide.</p> -->
            </div>
          </div>
          <div class="carousel-item" data-bs-interval="2000">
            <img src="img\img9.jpeg" class="img-fluid imgwidth rounded" alt="image4">
            <div class="carousel-caption d-none d-md-block">
              <!-- <h5>Fourth slide label</h5> -->
              <!-- <p>Some representative placeholder content for the third slide.</p> -->
            </div>
          </div>
          <div class="carousel-item" data-bs-interval="2000">
            <img src="img\img10.jpeg" class="img-fluid imgwidth rounded" alt="image4">
            <div class="carousel-caption d-none d-md-block">
              <!-- <h5>Fourth slide label</h5> -->
              <!-- <p>Some representative placeholder content for the third slide.</p> -->
            </div>
          </div>
        </div>
        
        <!-- <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button> -->
    </div>
    <!-- carousel end -->
    <div>
      <p class="p">Hello <?php if (isset($_SESSION['name'])) {
        echo $_SESSION['name'];
      } else {
        echo $_SESSION['user_first_name'].' '.$_SESSION['user_last_name'];
      }
       ?></p>
    </div>

<!-- card group start -->
<div class="container">
      <div class="card-group m-4 justify-content-center">
        <div class="row gy-3">
          <!-- fetch upload_product from database start-->
          <?php
            // sql query to fetch product from database.
            $sql = "SELECT * FROM upload_product";
            // fatch the query or creating connection of sql query which is stored on the variable.
            $result = mysqli_query($conn,$sql);
            if($result){
              while ($row = mysqli_fetch_array($result)){
          ?>
          <!-- card start -->
          <div class="col-12 col-md-6 col-lg-4">
            <div class="card">
              <img src="<?= $row[4]; ?>" class="card-img-top" alt="img1" height="225rem"/>
              <div class="card-body">
                <h5 class="card-title"><?= $row[1]; ?></h5>
                <p class="card-text"><?= $row[2]; ?></p>
                <h5 class="card-title">Price : <?= number_format($row[3]); ?> Rs.</h5>
                <a href="product_purchase.php?id=<?= $row[0]; ?>" class="btn btn-primary">Buy Now</a>
              </div>
            </div>
          </div>
          <!-- card end -->
          <?php }
          }
          ?>
          <!-- fetch upload_product from database end-->
          
        </div>
      </div>
    </div>
    <!-- card group end -->

    <!-- Bootstrap js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>
<!-- html and bootstrap end -->