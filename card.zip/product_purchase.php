<!-- php start -->
<?php
  // session start.
  session_start();
  // if without logging someone enter the web site the go to the logout page.
  if (!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true) {
    header("Location:login.php");
    exit;
  }
  // otherwise run the current page.
  else{
    $loggedin = false;
    // if admin dosen't enter on the web site then set as the user page.
    if (!isset($_SESSION['admin']) || isset($_SESSION['admin'])!=true) {
      $admin = false;
    }
    // otherwise set as the admin page.
    else {
      $admin = true;
    }
    // call the database.
    include('partials/_connection.php');  
    include('partials/_bsicon.php');

    if (isset($_GET['id'])) {
        $sno = $_GET['id'];
        // sql query to fetch product from database.
        $sql = "SELECT * FROM upload_product WHERE sno = '$sno'";
        // fatch the query or creating connection of sql query which is stored on the variable.
        $result = mysqli_query($conn,$sql);
        $row = mysqli_fetch_array($result);

        $product_name = $row[1];
        $product_description = $row[2];
        $product_price = $row[3];
        $delivary_charge = 100;
        $final_price = $product_price + $delivary_charge;
        $product_image = $row[4];
    } else {
        echo "Try again...";
    }
  }
?>
<!-- php end -->
<!-- html and bootstrap start -->
<!DOCTYPE html>
<html lang="en">
<!-- head start -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Your Product</title>
    <link rel="stylesheet" href="css/style.css">
    <!-- bootstrap css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>
<body>
<?php include_once('partials/_nav.php');?>
    <div>
      <p class="p">Hello <?php if (isset($_SESSION['name'])) {
        echo $_SESSION['name'];
      } else {
        echo $_SESSION['user_first_name'].' '.$_SESSION['user_last_name'];
      }
       ?></p>
    </div>
    <!-- table start -->
    <div class='container'>
        <table class='table table-hover table-bordered border-primary'>
            <tr class=''>
                <th>Product Name</th>
                <td><?= $product_name; ?></td>
                <td class="text-center" rowspan="5"><img src="<?= $row[4]; ?>" class="card-img-top" alt="img1"/></td>
            </tr>
            <tr class=''>
                <th>Product Details</th>
                <td><?= $product_description; ?></td>
            </tr>
            <tr class=''>
                <th>Product Price</th>
                <td><?= number_format($product_price); ?></td>
            </tr>
            <tr class=''>
                <th>Delivary Charge</th>
                <td><?= number_format($delivary_charge); ?></td>
            </tr>
            <tr class=''>
                <th>Total Price</th>
                <td><?= number_format($final_price); ?></td>
            </tr>
        </table>
    </div>
    <!-- table end -->
    <!-- Information Form start-->
    <div class="d-flex flex-column align-items-center mt-5">
        <form class="px-4 py-3" method="post">
            <input type="hidden" name="product_name" <?= $product_name; ?>>
            <input type="hidden" name="product_price" <?= $final_price; ?>>
          <!-- enter name start-->
          <div class="mb-3">
            <label for="exampleDropdownFormname" class="form-label">Name</label>
            <input type="text" class="form-control" id="exampleDropdownFormname" placeholder="Enter your name" name="name" maxlength="30" required>
          </div>
          <!-- enter name end-->
          <!-- enter number start-->
          <div class="mb-3">
            <label for="exampleDropdownFormnumber" class="form-label">Phone No.</label>
            <input type="tel" class="form-control" id="exampleDropdownFormnumber" placeholder="Enter your number" name="number" maxlength="10" required>
          </div>
          <!-- enter number end-->
          <!-- enter email start-->
          <div class="mb-3">
            <label for="exampleDropdownFormEmail1" class="form-label">Email address</label>
            <input type="email" class="form-control" id="exampleDropdownFormEmail1" placeholder="email@example.com" name="email" maxlength="30" required>
          </div>
          <!-- enter email end-->
          <!-- enter number start-->
          <div class="mb-3">
            <label for="exampleDropdownFormnumber" class="form-label">Address</label>
            <input type="text" class="form-control" id="exampleDropdownFormnumber" placeholder="Enter your address" name="address" maxlength="255" required>
          </div>
          <!-- enter number end-->
          <input type="submit" name="submit" class="btn btn-primary" value="Click to pay : Rs. <?= number_format($final_price); ?>">
        </form>
      </div>
    <!-- Information Form end-->

    <!-- Bootstrap js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>
<!-- html and bootstrap end -->